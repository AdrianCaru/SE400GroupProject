/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

/**
 *
 * @author it.student
 */
public class LatLonCoord {
    private int latDeg;
    private int latMin;
    private int latSec;
    private boolean latIsNorth;
    
    private int lonDeg;
    private int lonMin;
    private int lonSec;
    private boolean lonIsWest;
    
    public LatLonCoord()
    {
        this(0,0,0,true,0,0,0,false);
    }
    public LatLonCoord(int latDegIn, int latMinIn, int latSecIn, boolean latNorthIn, int lonDegIn, int lonMinIn, int lonSecIn, boolean lonWestIn)
    {
       this.SetCoord(latDegIn, latMinIn, latSecIn, latNorthIn, lonDegIn, lonMinIn, lonSecIn, lonWestIn);
    }
    
    //Essentially a copy of the constructor for setting new points.
    public void SetCoord(int latDegIn, int latMinIn, int latSecIn, boolean latNorthIn, int lonDegIn, int lonMinIn, int lonSecIn, boolean lonWestIn)
    {
        if(latDegIn > 90 || latDegIn < 0)
        {
            throw new IllegalArgumentException("Latitude degrees out of range! 0-90°");
        }
        else if (latDegIn == 90 && (latMinIn != 0 || latSecIn != 0))
        {
            throw new IllegalArgumentException("Latitude out of range due to a total of more than 90°.");
        }
        if(latMinIn > 59 || latDegIn < 0)
        {
            throw new IllegalArgumentException("Latitude minutes out of range! 0-59");
        }
        if(latSecIn > 59 || latDegIn < 0)
        {
            throw new IllegalArgumentException("Latitude seconds out of range! 0-59");
        }
        
        if(lonDegIn > 180 || lonDegIn < 0)
        {
            throw new IllegalArgumentException("Longitude degrees out of range! 0-180°");
        }
        else if (lonDegIn == 180 && (lonMinIn != 0 || lonSecIn != 0))
        {
            throw new IllegalArgumentException("Longitude out of range due to a total of more than 180°.");
        }
        if(lonMinIn > 59 || lonDegIn < 0)
        {
            throw new IllegalArgumentException("Longitude minutes out of range! 0-59");
        }
        if(lonSecIn > 59 || lonDegIn < 0)
        {
            throw new IllegalArgumentException("Longitude seconds out of range! 0-59");
        }
        
       latDeg = latDegIn;
       lonDeg = lonDegIn;
       latMin = latMinIn;
       lonMin = lonMinIn;
       latSec = latSecIn;
       lonSec = lonSecIn;
       
       latIsNorth = latNorthIn;
       lonIsWest = lonWestIn;
    }
    
    public void display()
    {
        System.out.print(latDeg + "° " + latMin + "' " + latSec + "\" ");
        if(latIsNorth)
        {
            System.out.print("N, ");
        }
        else
        {
            System.out.print("S, ");
        }
        System.out.print(lonDeg + "° " + lonMin + "' " + lonSec + "\" ");
        if(lonIsWest)
        {
            System.out.print("W");
        }
        else
        {
            System.out.print("E");
        }
            
    }
}

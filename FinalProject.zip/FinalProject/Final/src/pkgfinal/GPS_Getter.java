/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;
import java.util.Random;
import java.util.Date; 



/**
 *
 * @author it.student
 */
public class GPS_Getter {
    private LatLonCoord location = new LatLonCoord();
    private static Date d = new Date();
    private static Random r = new Random(d.getTime());
    public GPS_Getter()
    {        
        location.SetCoord(r.nextInt(89), r.nextInt(59), r.nextInt(59), r.nextBoolean(), r.nextInt(179), r.nextInt(59), r.nextInt(59), r.nextBoolean());  
    }
    
    public void getNewLocation()
    {        
        location.SetCoord(r.nextInt(89), r.nextInt(59), r.nextInt(59), r.nextBoolean(), r.nextInt(179), r.nextInt(59), r.nextInt(59), r.nextBoolean());
    }
    public void display()
    {
        location.display();
    }
}

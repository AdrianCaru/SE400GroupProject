 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

import java.util.Scanner;

/**
 *
 * @author it.student
 */
public class FinalPRRRROJECT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        GPS_Getter myCoord = new GPS_Getter();
        GPS_Getter CacheLoc = new GPS_Getter();
        
        
        System.out.print("You are at ");
        myCoord.display();
        System.out.print(".\n");
        
        Scanner s = new Scanner(System.in);
        s.nextLine();
        
        System.out.print("Scanning for caches");
        for(int i = 0; i < 5; i++)
        {
            try {
                Thread.sleep(400);
                } catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            System.out.print(".");
        }
            try {
                Thread.sleep(400);
                } catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            System.out.print("!");
            
        System.out.print("\nFound cache at ");
        CacheLoc.display();
        System.out.print(".\n");
        s.nextLine();
        
        System.out.print("Navigating to nearest cache");
        
        for(int i = 0; i < 10; i++)
        {
            try {
                Thread.sleep(500);
                } catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            System.out.print(".");
        }
            try {
                Thread.sleep(1000);
                } catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            System.out.print("!");
                try {
                Thread.sleep(1000);
                } catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
                
        System.out.print("\nNow at cache location.");
        
        s.nextLine();
    }
    
}
